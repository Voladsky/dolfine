﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Teacher : User
{
    private List<Pupil> pupils = new List<Pupil>();
    private List<Task> createdTasks = new List<Task>();
    private List<Test> createdTests = new List<Test>();
    private List<Form> forms = new List<Form>();
    private string graduation = "NULL";

    public Teacher (string _name, string _secondName, string _patronymic, string _login, string _password_hash, string _school, string _graduation) 
            : base (_name, _secondName, _patronymic, _login, _password_hash, _school)
    {
        graduation = _graduation;
    }

    public void addPupil(Pupil pupil)
    {
        pupils.Add(pupil);
    }

    public void AddTask(Task task)
    {
        createdTasks.Add(task);
    }

    public void addTest(Test test)
    {
        createdTests.Add(test);
    }

    public Form createForm()
    {
        Form form = new Form();
        forms.Add(form);
        return form;
    }

    public void giveTestToPupils(Form form, Test test)
    {
        form.giveTestToPupils(test);
    }

    public void giveTestToPupils(Pupil pupil, Test test)
    {
        pupil.addTest(test);
    }

    public void giveTestToPupils(IEnumerable<Pupil> pupil, Test test)
    {
        foreach (var p in pupil)
        {
            p.addTest(test);
        }
    }
}
