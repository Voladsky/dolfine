﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class TaskManager : MonoBehaviour
{
    Task CreateTask(string condition, int answer)
    {
        return null;
    }
}
