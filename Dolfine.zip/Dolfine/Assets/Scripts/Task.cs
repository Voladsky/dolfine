﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Task
{
    public int maxBall { get; private set; } = 0;
    private string text = "NULL";
    public string correctAnswer { get; private set; } = "NULL";

    public Task(int _maxBall, string _text, string _correctAnswer)
    {
        maxBall = _maxBall;
        text = _text;
        correctAnswer = _correctAnswer;
    }

    public Task createTask(TaskCreator taskCreator)
    {
        return null;
    }
}
