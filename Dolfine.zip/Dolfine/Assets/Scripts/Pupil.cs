﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pupil : User
{
    private List<Test> unDoneTests = new List<Test>();

    public Pupil(string _name, string _secondName, string _patronymic, string _login, string _password_hash, string _school, string _graduation)
            : base(_name, _secondName, _patronymic, _login, _password_hash, _school)
    {
        
    }

    public void addTest(Test test)
    {
        unDoneTests.Add(test);
    }
}
