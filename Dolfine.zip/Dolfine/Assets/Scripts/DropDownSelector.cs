﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DropDownSelector : MonoBehaviour
{
    public TMP_Dropdown Dropdown;
    public GameObject[] Lists;
    void Start()
    {
        DropDown();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void DropDown()
    {
        for(int i=0; i<Lists.Length;i++)
        {
            if (i == Dropdown.value)
            {
                Lists[i].SetActive(true);
            }
            else
                Lists[i].SetActive(false);
        }
    }
}
