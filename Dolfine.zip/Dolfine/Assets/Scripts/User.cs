﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class User
{
    public static Dictionary <string, User> users = new Dictionary<string, User>();
    public static int ID = 0;
    /// <summary>
    /// Имя
    /// </summary>
    private string name = "NULL";
    /// <summary>
    /// Фамилия
    /// </summary>
    private string secondName = "NULL";
    /// <summary>
    /// Отчество
    /// </summary>
    private string patronymic = "NULL";
    /// <summary>
    /// login
    /// </summary>
    public string login { get; private set; }
    /// <summary>
    /// Хэш-код пароля
    /// </summary>
    public string password_hash { get; private set; }
    /// <summary>
    /// Школа
    /// </summary>
    private string school;
    public int id { get; private set; }

    public User(string _name, string _secondName, string _patronymic, string _login, string _password_hash, string _school)
    {
        id = ID;
        ID++;
        name = _name;
        secondName = _secondName;
        patronymic = _patronymic;
        login = _login;
        password_hash = _password_hash;
        school = _school;
        users.Add(login, this);
    }

    public User(User user)
    {
        id = user.id;
        name = user.name;
        secondName = user.secondName;
        patronymic = user.patronymic;
        login = user.login;
        password_hash = user.password_hash;
        school = user.school;
        users.Add(login, this);
    }
}
