﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test
{
    private List<Task> tasks = new List<Task>();

    public Test(Test test)
    {
        tasks = test.tasks;
    }

    public void addTask(Task task)
    {
        tasks.Add(task);
    }

    public void removeTask(Task task)
    {
        tasks.Remove(task);
    }

    public Test createTest(TestCreator testCreator)
    {
        return null;
    }
}
