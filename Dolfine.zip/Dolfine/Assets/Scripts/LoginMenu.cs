﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class LoginMenu : MonoBehaviour
{
    [Header("Settings")] 
    [SerializeField] private bool isTeacher = false;
    [SerializeField] private TMP_Text warnigPasswords;
    [SerializeField] private TMP_Text warnigBornDate;
    [SerializeField] private TMP_Text warning_all;

    [Header("Registration_ALL")]
    [SerializeField] private TMP_InputField name;
    [SerializeField] private TMP_InputField secondName;
    [Tooltip("Отчество")] [SerializeField] private TMP_InputField patronymic;
    [SerializeField] private TMP_InputField login;
    [SerializeField] private TMP_InputField password;
    [Tooltip("Проверка пароля")] [SerializeField] private TMP_InputField passwordCheck;
    [SerializeField] private TMP_InputField school;
    [SerializeField] private TMP_InputField bornDate;

    [Header("Registration_TEACHER")]
    [SerializeField] private TMP_InputField graduation;

    public void RegisterUser()
    {
        if (login.text.Equals("")) { showWarning("Неверный логин"); return; }
        if (User.users.ContainsKey(login.text)) { showWarning("Такой логин уже существует"); return; }
        if (name.text.Equals("")) { showWarning("Имя не должно быть пустым"); return; }
        if (secondName.text.Equals("")) { showWarning("Фамилия не должна быть пустой"); return; }
        if (patronymic.text.Equals("")) { showWarning("Отчество не должно быть пустым"); return; }

        if (isTeacher)
        {
            Teacher teacher = new Teacher(name.text, secondName.text, patronymic.text, login.text, getPasswordHash(password.text), graduation.text, graduation.text);
        }
    }

    private string getPasswordHash(string password)
    {
        string ret = "";

        ret = password.GetHashCode().ToString();

        return ret;
    }

    private void Update()
    {
        if (!password.text.Equals(passwordCheck.text) && !password.text.Equals("") && !passwordCheck.text.Equals("")) 
            warnigPasswords.gameObject.SetActive(true);
        else
            warnigPasswords.gameObject.SetActive(false);

        string[] help = bornDate.text.Split('.');
        if (help.Length != 3 || help[0].Length != 2 || help[1].Length != 2 || help[2].Length != 4)
            warnigBornDate.gameObject.SetActive(true);
        else
            warnigBornDate.gameObject.SetActive(false);

        Debug.Log(User.users.Count);
    }

    private void showWarning(string warning)
    {
        warning_all.text = warning;
        warning_all.gameObject.SetActive(true);
    }
}
