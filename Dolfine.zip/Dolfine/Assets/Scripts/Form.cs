﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Form : MonoBehaviour
{
    private List<Pupil> pupils = new List<Pupil>();

    public void addPupil(Pupil pupil)
    {
        pupils.Add(pupil);
    }

    public void addPupil(IEnumerable<Pupil> pupil)
    {
        pupils.AddRange(pupil);
    }

    public void addPupil(Pupil[] pupil)
    {
        foreach (var p in pupil)
            pupils.Add(p);
    }

    public void giveTestToPupils(Test test)
    {
        foreach (var p in pupils)
        {
            p.addTest(test);
        }
    }
}
