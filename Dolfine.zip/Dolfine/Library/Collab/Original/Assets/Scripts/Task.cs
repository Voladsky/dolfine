﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Task : MonoBehaviour
{
    string Condition;
    int Answer;
    List<char> AdditionalVariables;
    List<string> Formulas;
    List<int> AdditionalValues;
}
